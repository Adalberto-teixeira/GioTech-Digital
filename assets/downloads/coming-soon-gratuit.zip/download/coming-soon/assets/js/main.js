lucide.createIcons();

const $=s=>document.querySelector(s);

const launchDate=new Date("2026-10-15T09:00:00");

function updateCountdown(){
  let diff=Math.max(0,launchDate-new Date());

  const days=Math.floor(diff/86400000);
  diff%=86400000;
  const hours=Math.floor(diff/3600000);
  diff%=3600000;
  const minutes=Math.floor(diff/60000);
  const seconds=Math.floor((diff%60000)/1000);

  $("#days").textContent=String(days).padStart(2,"0");
  $("#hours").textContent=String(hours).padStart(2,"0");
  $("#minutes").textContent=String(minutes).padStart(2,"0");
  $("#seconds").textContent=String(seconds).padStart(2,"0");
}
updateCountdown();
setInterval(updateCountdown,1000);

function updateClock(){
  $("#clock").textContent=new Date().toLocaleTimeString("fr-FR",{hour12:false});
}
updateClock();
setInterval(updateClock,1000);

$("#notifyForm").addEventListener("submit",e=>{
  e.preventDefault();
  $("#formStatus").textContent="✓ Merci ! Vous serez prévenu au lancement.";
  e.currentTarget.reset();
});
