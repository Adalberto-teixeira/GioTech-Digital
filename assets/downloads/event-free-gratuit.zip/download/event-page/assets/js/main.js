lucide.createIcons();
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const target=new Date("2026-09-18T14:00:00");
function countdown(){
 let d=Math.max(0,target-new Date());
 const days=Math.floor(d/86400000); d%=86400000;
 const h=Math.floor(d/3600000); d%=3600000;
 const m=Math.floor(d/60000), s=Math.floor((d%60000)/1000);
 $("#days").textContent=String(days).padStart(2,"0");
 $("#hours").textContent=String(h).padStart(2,"0");
 $("#minutes").textContent=String(m).padStart(2,"0");
 $("#seconds").textContent=String(s).padStart(2,"0");
}
countdown(); setInterval(countdown,1000);
$$("[data-ticket]").forEach(b=>b.onclick=()=>{$("#ticketName").textContent=b.dataset.ticket;$("#modal").classList.add("open")});
$("#close").onclick=()=>$("#modal").classList.remove("open");
$("#booking").onsubmit=e=>{e.preventDefault();$("#status").textContent="✓ Démonstration : réservation enregistrée.";setTimeout(()=>$("#modal").classList.remove("open"),1800)};