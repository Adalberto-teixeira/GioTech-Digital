# GioTech Specialized Component 002

Demo: demo/index.html
Clean downloadable component: download/commerce-header.zip

The clean ZIP includes only the header component files and no GioTech advertising.
