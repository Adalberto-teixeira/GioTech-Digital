lucide.createIcons();

const megaToggle=document.getElementById("megaToggle");
const megaMenu=document.getElementById("megaMenu");
const mobileDrawer=document.getElementById("mobileDrawer");

megaToggle?.addEventListener("click",()=>{
  megaMenu.classList.toggle("open");
});

document.addEventListener("click",(e)=>{
  if(!megaMenu.contains(e.target) && !megaToggle.contains(e.target)){
    megaMenu.classList.remove("open");
  }
});

document.getElementById("menuOpen")?.addEventListener("click",()=>{
  mobileDrawer.classList.add("open");
});

document.getElementById("menuClose")?.addEventListener("click",()=>{
  mobileDrawer.classList.remove("open");
});

document.getElementById("searchForm")?.addEventListener("submit",(e)=>{
  e.preventDefault();
});
