lucide.createIcons();

document.getElementById("goBack").addEventListener("click",()=>{
  if(history.length>1) history.back();
  else location.href="/";
});

function updateClock(){
  const now=new Date();
  document.getElementById("clock").textContent=
    now.toLocaleTimeString("fr-FR",{hour12:false});
}
updateClock();
setInterval(updateClock,1000);
