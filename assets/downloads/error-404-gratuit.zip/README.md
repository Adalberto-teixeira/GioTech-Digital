# GioTech Digital — Specialized Page 001

## Demo
`demo/index.html`

Page de présentation GioTech avec :
- mention "100% GRATUIT"
- bouton Télécharger gratuitement
- aperçu live en iframe
- informations techniques
- footer GioTech

## Download propre
`download/404-page.zip`

Le ZIP téléchargé contient uniquement :
- index.html
- assets/css/style.css
- assets/js/main.js

Aucune publicité ou mention GioTech dans le template téléchargé.
