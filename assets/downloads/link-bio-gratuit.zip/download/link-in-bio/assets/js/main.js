lucide.createIcons();

const $=s=>document.querySelector(s);

function toast(text){
  const t=$("#toast");
  t.textContent=text;
  t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),1500);
}

$("#themeToggle").addEventListener("click",()=>{
  document.body.classList.toggle("dark");
  $("#themeToggle").innerHTML=document.body.classList.contains("dark")
    ? '<i data-lucide="sun"></i>'
    : '<i data-lucide="moon"></i>';
  lucide.createIcons();
});

$("#shareButton").addEventListener("click",async()=>{
  try{
    if(navigator.share){
      await navigator.share({
        title:"Maya Laurent",
        text:"Découvrez mes liens",
        url:location.href
      });
    }else{
      await navigator.clipboard.writeText(location.href);
      toast("Lien copié");
    }
  }catch(e){}
});

let playing=false;
$("#playButton").addEventListener("click",()=>{
  playing=!playing;
  $("#playButton").innerHTML=playing
    ? '<i data-lucide="pause"></i>'
    : '<i data-lucide="play"></i>';
  lucide.createIcons();
  toast(playing?"Lecture démo":"Pause");
});
