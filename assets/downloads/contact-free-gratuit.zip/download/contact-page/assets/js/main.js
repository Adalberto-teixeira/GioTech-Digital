lucide.createIcons();
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let budget="";
$$("[data-budget]").forEach(b=>b.onclick=()=>{$$("[data-budget]").forEach(x=>x.classList.remove("active"));b.classList.add("active");budget=b.dataset.budget});
$("#contactForm").onsubmit=e=>{
 e.preventDefault();
 $("#status").textContent="✓ Merci ! Votre message de démonstration a bien été envoyé.";
 $("#toast").classList.add("show");
 setTimeout(()=>$("#toast").classList.remove("show"),1800);
 e.target.reset(); $$("[data-budget]").forEach(x=>x.classList.remove("active"));
};