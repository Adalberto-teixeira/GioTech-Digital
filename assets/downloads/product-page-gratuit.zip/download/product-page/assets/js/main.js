lucide.createIcons();

const $=(s,c=document)=>c.querySelector(s);
const $$=(s,c=document)=>[...c.querySelectorAll(s)];

let cartCount=0;

function toast(text){
  const t=$("#toast");
  t.textContent=text;
  t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),1500);
}

$("#headerSearch").addEventListener("submit",e=>e.preventDefault());

$$("[data-image]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    $$("[data-image]").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");

    $$(".product-mock").forEach(x=>x.classList.remove("active"));
    $(".mock-"+btn.dataset.image).classList.add("active");
  });
});

$$("[data-color]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    $$("[data-color]").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");
    $("#selectedColor").textContent=btn.dataset.color;
  });
});

$$("[data-switch]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    $$("[data-switch]").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");
    $("#selectedSwitch").textContent=btn.dataset.switch;
  });
});

function addToCart(){
  cartCount+=Number($("#quantity")?.value||1);
  $("#headerCartCount").textContent=cartCount;
  toast("Produit ajouté au panier");
}

$("#addCart").addEventListener("click",addToCart);
$("#mobileAdd").addEventListener("click",addToCart);

$("#wishMain").addEventListener("click",e=>{
  e.currentTarget.classList.toggle("active");
  e.currentTarget.innerHTML=e.currentTarget.classList.contains("active")
    ? '<i data-lucide="heart"></i> Ajouté à ma liste'
    : '<i data-lucide="heart"></i> Ajouter à ma liste';
  lucide.createIcons();
  toast(e.currentTarget.classList.contains("active")?"Ajouté aux favoris":"Retiré des favoris");
});

$$("[data-related]").forEach(btn=>{
  btn.addEventListener("click",()=>toast(btn.dataset.related+" ajouté"));
});

$("#zoomOpen").addEventListener("click",()=>$("#zoomModal").classList.add("open"));
$("#zoomClose").addEventListener("click",()=>$("#zoomModal").classList.remove("open"));

function openCheckout(){
  const qty=Number($("#quantity")?.value||1);
  $("#checkoutQty").textContent=qty+" × 89,99 €";
  $("#checkoutTotal").textContent="Total : "+(89.99*qty).toLocaleString("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2})+" €";
  $("#checkoutModal").classList.add("open");
}

$("#buyNow").addEventListener("click",openCheckout);
$("#checkoutClose").addEventListener("click",()=>$("#checkoutModal").classList.remove("open"));

$("#checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();
  $("#checkoutStatus").textContent="✓ Commande de démonstration confirmée. Aucun paiement réel.";
  e.currentTarget.reset();
  setTimeout(()=>$("#checkoutModal").classList.remove("open"),2100);
});

let secs=2*3600+14*60+33;
function updateDeal(){
  secs=Math.max(0,secs-1);
  const h=Math.floor(secs/3600),m=Math.floor(secs%3600/60),s=secs%60;
  $("#dealTimer").textContent=[h,m,s].map(v=>String(v).padStart(2,"0")).join(":");
}
setInterval(updateDeal,1000);
